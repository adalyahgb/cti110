user_name=('Pat')
print('Hello', user_name , 'and welcome to CS Online!')